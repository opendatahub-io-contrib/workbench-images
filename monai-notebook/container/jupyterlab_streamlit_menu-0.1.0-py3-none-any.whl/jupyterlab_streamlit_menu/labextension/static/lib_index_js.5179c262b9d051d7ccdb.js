"use strict";
(self["webpackChunk_jupyterlab_odh_streamlit_menu"] = self["webpackChunk_jupyterlab_odh_streamlit_menu"] || []).push([["lib_index_js"],{

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "streamlitIcon": () => (/* binding */ streamlitIcon)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/filebrowser */ "webpack/sharing/consume/default/@jupyterlab/filebrowser");
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_terminal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/terminal */ "webpack/sharing/consume/default/@jupyterlab/terminal");
/* harmony import */ var _jupyterlab_terminal__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_terminal__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _style_assets_streamlit_icon_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../style/assets/streamlit-icon.svg */ "./style/assets/streamlit-icon.svg");







const streamlitIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_4__.LabIcon({
    name: 'barpkg:streamlit',
    svgstr: _style_assets_streamlit_icon_svg__WEBPACK_IMPORTED_MODULE_5__["default"]
});
/**
 * Initialization data for the main menu example.
 */
const extension = {
    id: 'streamlit-menu',
    autoStart: true,
    requires: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ICommandPalette, _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__.IFileBrowserFactory],
    activate: (app, palette, browserFactory) => {
        const { commands } = app;
        const command = 'jlab-odh:streamlit-menu';
        const commandSelect = 'jlab-odh:streamlit-select';
        let streamlitNextPort = 8501;
        // Streamlit launcher function
        async function launchStreamlit(filePath) {
            let currentLocation = window.location.href;
            console.log(currentLocation);
            console.log(currentLocation.indexOf('/lab'));
            let mainLocation = currentLocation.slice(0, currentLocation.indexOf('/lab'));
            console.log(mainLocation);
            let streamlitLocation = mainLocation + '/proxy/' + streamlitNextPort + '/';
            console.log(streamlitLocation);
            let launchCommand = 'streamlit-launcher.sh -f ' + filePath + ' -p ' + streamlitNextPort + ' -s ' + streamlitLocation;
            console.log(launchCommand);
            const manager = new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_2__.TerminalManager();
            const s1 = await manager.startNew();
            const term1 = new _jupyterlab_terminal__WEBPACK_IMPORTED_MODULE_3__.Terminal(s1, {
                initialCommand: `${launchCommand}`,
                shutdownOnClose: true
            });
            term1.title.closable = true;
            const widget = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.MainAreaWidget({ content: term1 });
            widget.id = `jupyter-executor-${Date.now()}`;
            widget.title.label = 'Execute';
            widget.title.closable = true;
            if (!widget.isAttached) {
                // Attach the widget to the main work area if it's not there
                app.shell.add(widget, 'main');
            }
            // Activate the widget
            app.shell.activateById(widget.id);
            // Launch Streamlit in a new tab after 2 seconds
            // dot is a a fix for trailing slash being filtered
            setTimeout(() => {
                window.open(streamlitLocation + '.');
            }, 4000);
            // Increment port for next launch
            streamlitNextPort += 1;
        }
        commands.addCommand(commandSelect, {
            label: 'Select file to Streamlit...',
            caption: 'Select file to Streamlit...',
            execute: async (args) => {
                const manager = browserFactory.defaultBrowser.model.manager;
                const dialog = _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__.FileDialog.getOpenFiles({
                    manager,
                    filter: model => model.type == 'file' // optional (model: Contents.IModel) => boolean
                });
                dialog.then(async (result) => {
                    if (result.button.accept) {
                        if (result.button.label === 'Select') {
                            let files = result.value;
                            if (files[0].path.endsWith('.py')) {
                                launchStreamlit(files[0].path);
                            }
                            else {
                                (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.showDialog)({
                                    title: "Error",
                                    body: 'You must select a Python file to be able to Streamlit it.',
                                    buttons: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Dialog.okButton()],
                                }).catch((e) => console.log(e));
                            }
                        }
                        else {
                            console.log('Cancelled');
                        }
                    }
                });
            },
        });
        // Add the command to the command palette
        const category = 'Extension Examples';
        palette.addItem({
            command,
            category,
            args: { origin: 'from the palette' },
        });
        // Add Context menu
        commands.addCommand('jlab-odh:streamlit-context', {
            label: 'Streamlit this file',
            caption: "Launch Streamlit with this file",
            icon: streamlitIcon,
            execute: () => {
                const file = browserFactory.tracker.currentWidget.selectedItems().next();
                launchStreamlit(file.path).catch((e) => console.log(e));
            },
        });
    },
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (extension);


/***/ }),

/***/ "./style/assets/streamlit-icon.svg":
/*!*****************************************!*\
  !*** ./style/assets/streamlit-icon.svg ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<svg width=\"301\" height=\"165\" viewBox=\"0 0 301 165\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<path d=\"M150.731 101.547L98.1387 73.7471L6.84674 25.4969C6.7634 25.4136 6.59674 25.4136 6.51341 25.4136C3.18007 23.8303 -0.236608 27.1636 1.0134 30.497L47.5302 149.139L47.5385 149.164C47.5885 149.281 47.6302 149.397 47.6802 149.514C49.5885 153.939 53.7552 156.672 58.2886 157.747C58.6719 157.831 58.9461 157.906 59.4064 157.998C59.8645 158.1 60.5052 158.239 61.0552 158.281C61.1469 158.289 61.2302 158.289 61.3219 158.297H61.3886C61.4552 158.306 61.5219 158.306 61.5886 158.314H61.6802C61.7386 158.322 61.8052 158.322 61.8636 158.322H61.9719C62.0386 158.331 62.1052 158.331 62.1719 158.331V158.331C121.084 164.754 180.519 164.754 239.431 158.331V158.331C240.139 158.331 240.831 158.297 241.497 158.231C241.714 158.206 241.922 158.181 242.131 158.156C242.156 158.147 242.189 158.147 242.214 158.139C242.356 158.122 242.497 158.097 242.639 158.072C242.847 158.047 243.056 158.006 243.264 157.964C243.681 157.872 243.87 157.806 244.436 157.611C245.001 157.417 245.94 157.077 246.527 156.794C247.115 156.511 247.522 156.239 248.014 155.931C248.622 155.547 249.201 155.155 249.788 154.715C250.041 154.521 250.214 154.397 250.397 154.222L250.297 154.164L150.731 101.547Z\" fill=\"#FF4B4B\"/>\n<path d=\"M294.766 25.4981H294.683L203.357 73.7483L254.124 149.357L300.524 30.4981V30.3315C301.691 26.8314 298.108 23.6648 294.766 25.4981\" fill=\"#7D353B\"/>\n<path d=\"M155.598 2.55572C153.264 -0.852624 148.181 -0.852624 145.931 2.55572L98.1389 73.7477L150.731 101.548L250.398 154.222C251.024 153.609 251.526 153.012 252.056 152.381C252.806 151.456 253.506 150.465 254.123 149.356L203.356 73.7477L155.598 2.55572Z\" fill=\"#BD4043\"/>\n</svg>\n");

/***/ })

}]);
//# sourceMappingURL=lib_index_js.5179c262b9d051d7ccdb.js.map